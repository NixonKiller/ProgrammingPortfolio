#1. Generate a random number from 1-100
import random

attempts = 0


number = random.randint(1, 100)
guess = 0
print("Welcome to the number guessing game!")
while guess != number:
  guess = int(input("Enter your guess: "))
  attempts += 1
  if guess < number:
    print("Too low, try again!")
  elif guess > number:
      print("Too high, try again!")
  else:
      print("Congratulations, you guessed the number in", attempts, "attempts!")


